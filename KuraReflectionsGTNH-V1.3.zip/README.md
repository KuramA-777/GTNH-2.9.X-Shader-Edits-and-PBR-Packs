# Reflective Horizons
Provides specular maps for a bunch of Building blocks in GregTech: New Horizons, enabling Reflections.

