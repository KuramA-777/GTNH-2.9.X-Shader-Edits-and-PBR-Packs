# Neon Horizons
Provides emissive maps for a bunch of Building blocks in GregTech: New Horizons, enabling Neon like Emissives.

