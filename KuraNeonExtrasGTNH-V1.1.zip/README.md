# Texture Swaps Horizons
Provides some Alternative Textures for some Blocks, Mainly for Chisel

